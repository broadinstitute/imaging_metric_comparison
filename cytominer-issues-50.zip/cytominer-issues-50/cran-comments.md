## Test environments
* local OS X install, R 3.3.3
* ubuntu 14.04.5 LTS (on travis-ci), R 3.4.1
* win-builder

## R CMD check results
There were no ERRORs or WARNINGs or NOTEs for OS X and ubuntu.

There is 1 NOTE on winbuild:

- *New submission*: This is my first submission!

## Downstream dependencies

There are currently no downstream dependencies for this package.

